cd "$(dirname "$0")"

./adb wait-for-device

