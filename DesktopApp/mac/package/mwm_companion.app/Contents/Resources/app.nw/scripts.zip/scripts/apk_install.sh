#!/bin/bash

cd "$(dirname "$0")"

./adb install MakeWithMoto-release.apk