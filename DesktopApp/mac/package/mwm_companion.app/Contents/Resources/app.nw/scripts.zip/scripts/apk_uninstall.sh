#!/bin/bash

cd "$(dirname "$0")"

./adb uninstall com.makewithmoto