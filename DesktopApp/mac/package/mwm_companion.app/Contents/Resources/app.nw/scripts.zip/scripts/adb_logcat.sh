#!/bin/bash

cd "$(dirname "$0")"

./adb logcat 
