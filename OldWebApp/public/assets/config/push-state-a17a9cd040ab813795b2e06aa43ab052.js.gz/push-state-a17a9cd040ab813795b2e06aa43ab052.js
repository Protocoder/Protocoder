(function() {
  app.config(function($locationProvider) {
    return $locationProvider.html5Mode(false);
  });

}).call(this);
