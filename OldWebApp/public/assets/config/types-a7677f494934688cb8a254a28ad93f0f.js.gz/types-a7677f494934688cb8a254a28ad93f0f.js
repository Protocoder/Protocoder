(function() {
  window.Types = {
    Object: [],
    Global: ['function', 'var'],
    'moto': ['createDigitalOutput']
  };

}).call(this);
