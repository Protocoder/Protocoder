(function() {
  app.controller("AboutController", function($scope) {});

}).call(this);
