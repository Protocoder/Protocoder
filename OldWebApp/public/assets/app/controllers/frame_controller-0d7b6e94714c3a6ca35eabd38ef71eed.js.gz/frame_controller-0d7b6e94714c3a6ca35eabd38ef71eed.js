(function() {
  app.controller('FrameController', function($scope) {});

}).call(this);
