function setup() {
  // This is your initialization code
  // Setup your interface here
}

function loop() {
  // This gets called for every run
  // return true in this function to continue
  // to run, and return false to stop/quit
}
;
